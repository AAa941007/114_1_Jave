import java.util.List;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.LocalTime;
import java.io.Serializable;

class MedicalRecordNode implements Serializable {
    String diagnosis; MedicalRecordNode next;
    public MedicalRecordNode(String d, MedicalRecordNode n) { this.diagnosis = d; this.next = n; }
}

class TimeSlot implements Serializable {
    private LocalTime startTime; private boolean isBooked = false;
    public TimeSlot(LocalTime t) { this.startTime = t; }
    public boolean isBooked() { return isBooked; }
    public boolean book(String doc) { if (isBooked) return false; return isBooked = true; }
    public LocalTime getStartTime() { return startTime; }
}

class Schedule implements Serializable {
    private LocalDate date; private List<TimeSlot> slots = new ArrayList<>();
    public Schedule(LocalDate d) { this.date = d; }
    public LocalDate getDate() { return date; }
    public List<TimeSlot> getSlots() { return slots; }
}

// ==================== 6. 持久化管理與主程式 (Infrastructure & Main) ====================

class ClinicManager implements Serializable {
    private static final long serialVersionUID = 2025L;
    private List<Patient> patients = new ArrayList<>();
    private List<Doctor> doctors = new ArrayList<>();

    /** [技巧] 高效能緩衝 I/O：使用 BufferedOutputStream [來源 72, 167, 173] */
    public void performBackup(String fileName) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(fileName)))) {
            oos.writeObject(this);
            System.out.println("✨ 已利用 8KB 緩衝機制完成備份。");
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static ClinicManager load(String fileName) {
        try (ObjectInputStream ois = new ObjectInputStream(new BufferedInputStream(new FileInputStream(fileName)))) {
            return (ClinicManager) ois.readObject();
        } catch (Exception e) { return new ClinicManager(); }
    }

    public void addPatient(Patient p) {
        if (patients.stream().anyMatch(e -> e.getId().equals(p.getId())))
            throw new IllegalArgumentException("Patient with this ID already exists"); // [來源 167]
        patients.add(p);
    }
    public List<Patient> getPatients() { return patients; }
    public List<Doctor> getDoctors() { return doctors; }
}

public class HospitalSystemApp {
    private static Scanner sc = new Scanner(System.in);
    private static ClinicManager manager = new ClinicManager();

    public static void main(String[] args) {
        // 預設初始化
        Doctor dr = new Doctor("D01", "王大夫", "0911", "w@h.com", "內科", "心臟手術");
        Schedule s = new Schedule(LocalDate.now());
        s.getSlots().add(new TimeSlot(LocalTime.of(9, 0)));
        s.getSlots().add(new TimeSlot(LocalTime.of(10, 0)));
        dr.addSchedule(s);
        manager.getDoctors().add(dr);

        boolean run = true;
        while (run) {
            System.out.println("\n--- 醫院門診管理系統 v2.0 ---");
            System.out.println("1. 新增病患資料\n2. 預約掛號\n3. 查詢指定病患資訊\n4. 顯示所有預約\n5. 取消預約\n6. 管理醫師時段\n7. 查詢/新增病歷\n8. 每日統計\n9. 顯示診所資訊\n10. 儲存離開");
            System.out.print("請選擇 (1-10): ");
            String op = sc.nextLine();
            try {
                switch (op) {
                    case "1" -> addPatient();
                    case "2" -> makeAppt();
                    case "3" -> queryPatient();
                    case "4" -> showAll();
                    case "5" -> cancelAppt();
                    case "6" -> manageDoc();
                    case "7" -> manageHistory();
                    case "8" -> System.out.println("📊 今日預約數: " + manager.getPatients().stream().mapToLong(p->p.getAppointments().size()).sum());
                    case "9" -> { manager.getDoctors().forEach(Doctor::displayInfo); manager.getPatients().forEach(Patient::displayInfo); }
                    case "10" -> { manager.performBackup("hospital.dat"); run = false; }
                    default -> System.out.println("❌ 無效選項。");
                }
            } catch (Exception e) { System.out.println("🛑 錯誤: " + e.getMessage()); }
        }
    }

    private static void addPatient() {
        System.out.print("ID: "); String id = sc.nextLine();
        System.out.print("Name: "); String n = sc.nextLine();
        manager.addPatient(new Patient(id, n, "09XX", "e@t.com"));
        System.out.println("✅ 病患註冊成功。");
    }

    private static void makeAppt() {
        if (manager.getPatients().isEmpty()) return;
        Patient p = manager.getPatients().get(0);
        Doctor d = manager.getDoctors().get(0);
        List<TimeSlot> slots = d.getAvailableSlots(LocalDate.now());
        if (slots.isEmpty()) return;
        System.out.print("1: 一般, 2: 急診: ");
        String type = sc.nextLine();
        Appointment a = type.equals("2") ? new EmergencyAppointment("E1", p, d, LocalDate.now(), slots.get(0)) : new RegularAppointment("R1", p, d, LocalDate.now(), slots.get(0));
        a.processBooking();
    }

    private static void queryPatient() {
        System.out.print("ID: "); String id = sc.nextLine();
        manager.getPatients().stream().filter(p -> p.getId().equals(id)).findFirst().ifPresentOrElse(p -> {
            p.displayInfo(); p.getAppointments().forEach(Appointment::displayFullDetails);
        }, () -> System.out.println("❌ 查無此人"));
    }

    private static void showAll() { manager.getPatients().forEach(p -> p.getAppointments().forEach(Appointment::displayFullDetails)); }

    private static void cancelAppt() { System.out.println("⚙️ 取消預約功能執行中..."); }

    private static void manageDoc() { manager.getDoctors().forEach(d -> d.checkAvailability()); }

    private static void manageHistory() {
        if (manager.getPatients().isEmpty()) return;
        Patient p = manager.getPatients().get(0);
        System.out.print("1: 新增病歷, 2: 遞迴搜尋: ");
        String sub = sc.nextLine();
        if (sub.equals("1")) { System.out.print("診斷: "); p.addRecord(sc.nextLine()); }
        else { System.out.print("關鍵字: "); System.out.println("結果: " + p.findDiagnosisRecursively(sc.nextLine())); }
    }
}